#include <stdlib.h>
#include <stdio.h>

int main() {
	system("dir=`pwd`; qdjs \"$dir/app\"");
}
