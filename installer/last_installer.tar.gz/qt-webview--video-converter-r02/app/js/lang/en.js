window.en = {
	'Extract_files_please_wait' :'Extract files from tar, please wait',
	'copy_config_complete' :'Configure multihosts complete',
	'Start_copy' :'Coping new files',
	'create_fastxampp_folder' :'Create fastxampp folder',
	'Sorry_file_' :'Sorry, file',
	'_not_found_autorun_is_disable' :' not found, autorun is disable',
	'create_virtual_filesystem' :'Create temp filesystem in memory',
	'create_socket' :'Create socket',
	'run_fastxamppd' :'Run fastxamppd daemon',
	'thank_now_must_be_fastxampp' :'Thank you for choise FFMpeg GUI Qt5 WebView based, you can run it from menu Multimedia',
	'copy_launcher' :'Copy autorun files',
	'copy_launcher_files' :'Copy autorun service files',
	'Installation progress' : 'Installation progress',
	'Copy_Qt5_libraries': 'Copy Qt5 libraries',
	'Install_php': 'Download and install ffmpeg',
	'copy_extra_complete' :'Configure multihosts complete'
};
