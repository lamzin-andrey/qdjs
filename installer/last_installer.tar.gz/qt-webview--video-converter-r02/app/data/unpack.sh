#!/bin/bash

rm -f /opt/qt-desktop-js/hwnew
rm -f /opt/qt-desktop-js/runnewversion.sh
rm -f /tmp/qgjsvoqdjsVideoConverter
rm -f /tmp/qgjsvnqdjsVideoConverter