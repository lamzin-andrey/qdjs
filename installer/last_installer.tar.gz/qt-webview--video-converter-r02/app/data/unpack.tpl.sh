#! /bin/bash
echo [[Install php]]
apt-get install ffmpeg -yf
echo [[Start_copy]]
mkdir /opt/qt-desktop-js
mkdir /opt/qt-desktop-js/apps
cp -f -v [[source]] /opt/qt-desktop-js/apps/qdjsMp3TagEditor.tar.gz
echo [[Extract_files_please_wait]]
cd /opt/qt-desktop-js/apps
tar -xzvf /opt/qt-desktop-js/apps/qdjsMp3TagEditor.tar.gz
rm -f /opt/qt-desktop-js/apps/qdjsMp3TagEditor.tar.gz
echo 'extract_complete'
