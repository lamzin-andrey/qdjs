#! /bin/bash
dir=`pwd`

qdjs $dir/app
