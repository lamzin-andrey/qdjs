var APP_NAME = 'qdjsVideoConverter';
var QT_VERSION  = '5.2.1'; //просто для информации
var EXEC_FOLDER = '/opt/qt-desktop-js';
var EXEC_FILE   = 'hw';
var EXEC_NULL = 'Main_defaultFinExecHandler';
var TARGZ_NAME = APP_NAME + '.tar.gz';
var APP_TARGET_FOLDER = '/opt/qt-desktop-js/apps/' + APP_NAME;
var OLD_QDJS_VERSION_LOGFILE = '/tmp/qgjsvo' + APP_NAME;
var NEW_QDJS_VERSION_LOGFILE = '/tmp/qgjsvn' + APP_NAME;


//set depends from ubuntu modification
var USER_AUTORUN_FOLDER = '/home/[user]/.config/autostart';
var USER_MENU_FOLDER    = '/usr/share/applications';
var UNITY_FOLDER        = '/home/[user]/.local/shared/applications';//пока похоже что этот каталог есть только в unity окружении

$(main);
function main() {
	window.Exec = PHP;
	Exec.exec(Qt.appDir() + '/data/user.sh', 'Main_onGetUser');
}

function Main_onGetUser(stdout, stderr) {
	var userSection, xfceSection, kdeSection, mintSection, 
		xfceThemeSection, qdjsSection,
		buf = stdout.split('isXfce'),
		envObject = {};
	userSection = buf[0].split('user')[1];
	xfceSection = buf[1].split('isKde')[0];
	kdeSection  = buf[1].split('isKde')[1];
	mintSection = buf[1].split('isMint')[1];
	xfceThemeSection = buf[1].split('xfceThemeName')[1];
	qdjsSection = buf[1].split('qdjsVersion')[1];
	window.USER = $.trim(userSection);
	window.IS_KDE = window.IS_XFCE = window.IS_UNITY = window.IS_MINT = false;
	// Активная тема оформления xfce
	window.XFCE_ICON_THEME = '';
	
	if (~xfceSection.indexOf('xfdesktop')) {
		window.IS_XFCE = true;
	} else 	if (~mintSection.toLowerCase().indexOf('mint') ) {
		window.IS_MINT = true;
	} else 	if (~kdeSection.indexOf('kwin') || ~kdeSection.indexOf('kwin_x11') || ~kdeSection.indexOf('kde5d') ) {
		window.IS_KDE = true;
		if ( ~kdeSection.indexOf('kded5') ) {
			window.IS_KDE5 = true;
		} else {
			USER_AUTORUN_FOLDER = '/home/[user]/.kde/Autostart';
        }
	} else {
		window.IS_UNITY = true;
	}
	window.XFCE_ICON_THEME = $.trim(xfceThemeSection.replace('/Net/IconThemeName', ''));
	
	USER_AUTORUN_FOLDER = USER_AUTORUN_FOLDER.replace('[user]', USER);
	
	envObject.USER = window.USER;
	envObject.IS_KDE = window.IS_KDE;
	envObject.IS_KDE5 = window.IS_KDE5;
	envObject.IS_XFCE = window.IS_XFCE;
	envObject.IS_UNITY = window.IS_UNITY;
	envObject.IS_MINT = window.IS_MINT;
	envObject.USER_AUTORUN_FOLDER = window.USER_AUTORUN_FOLDER;
	envObject.XFCE_ICON_THEME = window.XFCE_ICON_THEME;
	PHP.file_put_contents(Qt.appDir() + '/env.json', JSON.stringify(envObject));
	
	Exec.exec('mkdir /home/' + USER + '/.config/' + APP_NAME, 'Main_onConfigFolderCreate');
}

function startInstall() {
	hide('hPhpInfoScreen');
	show('extractPBar');
	Extractor.init();
	Extractor.extract();
}

function Main_onConfigFolderCreate(stdout, stdin) {
	$('#btnOk').prop('disabled', false);
}
function Main_defaultFinExecHandler(o, e) {
}
