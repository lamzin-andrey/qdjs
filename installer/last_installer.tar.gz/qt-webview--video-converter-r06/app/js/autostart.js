'use strict';
var Autorun = {
	init:function(unpack) {
		copyFields(unpack, this);
		this.rcTpl = '#mount1MbRAM start\n\
mount -t tmpfs tmpfs /home/[USER]/.config/fastxampp -o size=1M\n\
# /mount1MbRAM';
	},
	createCommand : function(file) {
		//install_flash_plugin  localize и в распаковке предусмотреть! ориентируясь на create_fastxampp_folder
		var cmd = "\necho '" + __('install_flash_plugin') + "'\n",
			iconFolder = '/usr/share/icons/Faenza/apps/64', //если понадобится - смело измени, но это сохрани как qdjsIconFolder
			installFilesPath = Qt.appDir() + '/data/icons';
		// cmd += this.createFolderCommand(EXEC_FOLDER); // это просто пример
		
		//patch rc.local
		// тут это просто не нужно
		/*if (!this.systemCtlIsEnable()) {
			cmd += this.createRcCommand();
		} else {
			cmd +=  this.createSystemCtlCommand();
		}*/
		
		//иконка инсталлятора для GUI установщиков приложений
		// iconFolder + '/exec.png';
		
		
		//Для авторана использовать desktop запускающий лаунчер
		//alert('Before createAutorunDesktopFile');
		var isUnity = this.isUnityEnv();
		if (!isUnity) {//для юнити автозапуска не будет, будет значок в левом меню
			// Здесь нечего запускать при старте this.createAutorunDesktopFile(fastxamppFilesPath);//arg и вообще подумать
		}
		
		
		
		// Здесь подготовка комнады install.sh (замена имени темы оформления xubuntu thunar на то, что используется)
		cmd += this.patchInstallPluginScript();
		
		// И копирование env.json который формируется в main
		cmd += this.cp(Qt.appDir() + '/env.json', APP_TARGET_FOLDER + '/app/env.json');
		// И создание иконки в меню [Игры(?)] конечно
		cmd += this.createMenuItem(APP_NAME);
		// Обновить версию qdjs TODO
		cmd += this.updateQdjsBinCmd();
		PHP.file_put_contents(file, cmd, FILE_APPEND);
		
	},
	/**
	 * @description Здесь подготовка комнады install.sh (замена имени темы оформления xubuntu thunar на то, что используется)
	 * @return String фрагмент команды запуска скрипта установки плагина
	*/
	patchInstallPluginScript:function() {
		
		// Эти команды в любом случае идут после распаковки.
		// Поэтому преписываем файл install и запускаем его
		// И запись запуска этого скрипта в конец файла
		var targetFile = APP_TARGET_FOLDER + '/app/flash_addons/flashplayer/install.sh',
			template = Qt.appDir() + '/data/bin/install.tpl.sh',
			tmpFile = Qt.appDir() + '/data/bin/install.sh',
			content = PHP.file_get_contents(template),
			iconCmd = '/opt/qt-desktop-js/apps/qdjsFlash/app/i/icons/setmime-run-in-console.sh [ACTIVE_THEME]',
			cmd = '';
		if (!window.XFCE_ICON_THEME) {
			window.XFCE_ICON_THEME = '';
		}
		if (window.XFCE_ICON_THEME) {
			// Добавить команду запуска установщика иконок
			iconCmd = iconCmd.replace('[ACTIVE_THEME]', XFCE_ICON_THEME);
			content = content.replace('[INSTALL_ICON_CMD]', iconCmd);
		} else {
			content = content.replace('[INSTALL_ICON_CMD]', '');
		}
		
		PHP.file_put_contents(tmpFile, content);
		cmd += '\ncp -fv ' + tmpFile + ' ' + targetFile;
		cmd += '\n' + targetFile + '\n';
		
		return cmd;
	},
	/**
	 * @description 
	 * @return {String} команду копирования файла запуска из меню программ
	*/
	createMenuItem:function(shortcutName) {
		var dir = Qt.appDir() + '/data/shortcuts';
		var desktop = PHP.file_get_contents(dir + '/' + shortcutName + '.desktop.tpl');
		// desktop = desktop.replace('[version]', QT_VERSION);
		desktop = desktop.replace(/\[APP_BASE_NAME\]/mg, APP_NAME);
		PHP.file_put_contents(dir + '/' + shortcutName + '.desktop', desktop);
		var cmd = "\ncp -fv " + dir + '/' + shortcutName + '.desktop ' + USER_MENU_FOLDER + "/" + shortcutName + ".desktop\n";
		
		if (window.IS_KDE5) {
			/*cmd += "\nadd-apt-repository ppa:tehnick/xembed-sni-proxy";
			cmd += "\napt-get update";
			cmd += "\napt-get install -y plasma-systray-legacy";*/
		}
		
		return cmd;
	},
	/**
	 * * в main сделать детект kde 5 иначе лажа также можно осторожно использовать  UNITY_FOLDER
	 * @return {Boolean} true если существует UNITY_FOLDER и установлена IS_UNITY
	*/
	isUnityEnv:function() {
		return IS_UNITY;
	},
	/**
	 * canonical favorites add fastxampp.desktop 
	*/
	createUnityLauncherItem:function() {
		Exec.exec("gsettings get com.canonical.Unity.Launcher favorites", 'Autostart_OnFinishGetUnityPanelItems');
	},
	/**
	 * Команда создания файлов сервиса и регистрации сервиса
	*/
	createSystemCtlCommand:function() {
		var rcTpl = this.rcTpl,
			file = EXEC_FOLDER + '/mountfs.sh', //daemon file
			result = '';
		//write daemon file instruction
		result = '\ncp -f -v ' + Qt.appDir() + '/data/systemctl/mountfs.sh ' + file;
		result += '\nchmod 766 ' + file;
		result += "\necho '#! /bin/sh' >> " + file;
		var cmd = rcTpl.replace(/\[USER\]/mg, USER);
		var a = cmd.split('\n');
		for (var i = 0; i < a.length; i++) {
			result += "\necho '" + a[i] + "' >> " + file;
		}
		//copy .service file
		result += '\ncp -f -v ' + Qt.appDir() + '/data/systemctl/' + APP_NAME + '.service ' + '/etc/systemd/system/' + APP_NAME + '.service';
		//enable service
		result += '\nsystemctl enable ' + APP_NAME + '.service';
		return result;
	},
	/**
	 * @return {Boolean} true if systemctl enabled
	*/
	systemCtlIsEnable:function() {
		return PHP.file_exists('/bin/systemctl');
	},
	/**
	 * В зависимости от типа операционной системы добавить в автостарт правильный значок запуска
	*/
	createAutorunDesktopFile:function(fastxamppFilesPath) {
		var cfc = this.createFolderCommand(USER_AUTORUN_FOLDER);
		var a = cfc.split('\n');
		for (var i = 0; i < a.length; i++) {
			cfc = $.trim(a[i]);
			if (cfc) {
				Exec.exec(cfc, EXEC_NULL);
			}
		}
		
		var desktopTemplate = '/fastxampprun.desktop.tpl',
			targetFile = '/fastxampprun.desktop';
		if (IS_UNITY) {
			desktopTemplate = '/fastxampp.desktop.tpl';
			targetFile      = '/fastxampp.desktop';
		}
		
		var desktop = PHP.file_get_contents(fastxamppFilesPath + desktopTemplate);
		desktop = desktop.replace('[version]', QT_VERSION);
		PHP.file_put_contents(fastxamppFilesPath + targetFile, desktop);
		PHP.file_put_contents(fastxamppFilesPath + '/launcher/app/data/locale', langName);
		setTimeout(function() {
			Exec.exec('cp -f ' + fastxamppFilesPath + targetFile + ' ' + USER_AUTORUN_FOLDER + targetFile, EXEC_NULL);
		}, 2000);
	},
	/** */
	createRcCommand:function() {
		var rcTpl = this.rcTpl,
			file = '/etc/init.d/rc.local',
			result = '';
		if (PHP.file_exists(file)
		) {
			var s = PHP.file_get_contents(file);
			if (s.indexOf('#fastxamppdaemon start') == -1) {
				var cmd = rcTpl.replace(/\[USER\]/mg, USER);
				var a = cmd.split('\n');
				for (var i = 0; i < a.length; i++) {
					result += "\necho '" + a[i] + "' >> " + file;
				}
				return result;
			}
		} else {
			alert(__('Sorry, file ') + file + __(' not found, autorun is disable'));
		}
		return '';
	},
	/***/
	createFolderCommand: function(s) {
		var a = s.split('/'), buf = [], q = '', i, sBuf;
		for (i = 0; i < a.length; i++) {
			sBuf = a[i];
			if (sBuf.length) {
				buf.push(sBuf);
				sBuf = buf.join('/');
				if (sBuf.length > 1) {
					sBuf = '/' + sBuf;
					if (!PHP.file_exists(sBuf)) {
						q += '\nmkdir ' + sBuf;
					}
				}
			}
		}
		return q;
	},
	/**
	 * @description Команда копирования файла
	 * @param {String} from
	 * @param {String} to
	 * @param {Boolean} isFolder = false
	 * @return String
	*/
	cp:function(from, to, isFolder) {
		return ('\ncp -' + (isFolder ? 'r' : '') + 'fv "' + from + '" "' + to + '"');
	},
	/**
	 * @description Собираем данные для возможности обновления бинарника qdjs
	 * 
	 * 1 копирование нового бинарника и скрипта запуска нового бинарника
	 * 2 Запуск старого и нового бинарника --version с выводом в лог
	 * 
	 *  // Проверяем версию приложения qdjs.
	 * // Если версия qdjs в составе инсталлера новее, чем версия qdjs в установленом, обновляем
	*/
	updateQdjsBinCmd:function() {
		
		//this.getQdjsNewFilepath()
		//this.getQdjsCurrentFilepath()
		var distQdjsFile = Qt.appDir() + '/bin/hw',
			destQdjsFile = EXEC_FOLDER + '/hwnew',
			result = '';
		result =  this.cp(distQdjsFile, destQdjsFile, false);
		result +=  this.cp( (Qt.appDir() + '/bin/runnewversion.sh'), 
							(EXEC_FOLDER + '/runnewversion.sh'), false);
		result += '\n' + EXEC_FOLDER + '/run.sh --version > ' + OLD_QDJS_VERSION_LOGFILE;
		result += '\n' + EXEC_FOLDER + '/runnewversion.sh --version > ' + NEW_QDJS_VERSION_LOGFILE;
		
		return result;
	},
	/**
	 * @description 
	 * Этот метод вызывается в Extractor.onFinExtract
	 * Проверяем версию приложения qdjs.
	 * Если версия qdjs в составе инсталлера новее, чем версия qdjs в установленом, обновляем
	*/
	updateQdjsBin:function() {
		var cmd = '#!/bin/bash\n', file = Qt.appDir() + '/data/unpack.sh';
		if (this.distHasNewBinary()) {
			cmd += this.cp(EXEC_FOLDER + '/hwnew', EXEC_FOLDER + '/hw', false);
		}
		cmd += '\nrm -f ' + EXEC_FOLDER + '/hwnew';
		cmd += '\nrm -f ' + EXEC_FOLDER + '/runnewversion.sh';
		
		cmd += '\nrm -f ' + OLD_QDJS_VERSION_LOGFILE;
		cmd += '\nrm -f ' + NEW_QDJS_VERSION_LOGFILE;
		
		// and check and update j.js
		try {
			cmd += this.updateJlibFileCmd();
		} catch (erre) {
			alert(erre);
		}
		
		PHP.file_put_contents(file, cmd);
		
		Exec.exec(file, 'F');
	},
	
	/**
	 * 
	 *  
	 * 
	 * @description Сравнивает все три компоненты x.y.z
	*/
	distHasNewBinary:function() {
		if (PHP.file_exists(EXEC_FOLDER + '/hwnew')
			&&  PHP.file_exists(OLD_QDJS_VERSION_LOGFILE)
			&&  PHP.file_exists(NEW_QDJS_VERSION_LOGFILE)
			) {
			var old = PHP.file_get_contents(OLD_QDJS_VERSION_LOGFILE).split('.'),
				newV = PHP.file_get_contents(NEW_QDJS_VERSION_LOGFILE).split('.');
			if (parseInt(newV[0]) > parseInt(old[0])) {
				
				return true;
			}
			if (parseInt(newV[1]) > parseInt(old[1])) {
				
				return true;
			}
			
			if (parseInt(newV[2]) > parseInt(old[2])) {
				
				return true;
			}
		}
		
		return false;
	},
	/**
	 * 
	 * @description Check and update j.js
	*/
	updateJlibFileCmd:function() {
		var newFile = Qt.appDir() + '/bin/j.js',
			oldFile = EXEC_FOLDER + '/default/tools/js/j.js',
			isNewVersion = this.compareVersion(this.getVersionFromFile(oldFile), this.getVersionFromFile(newFile) );
		if (isNewVersion) {
			return this.cp(newFile, oldFile, false);
		}
		
		return '\n';
	},
	/**
	 * @description Compare all three components
	 * return true if newVersion > oldVersion
	 * @return Boolean
	*/
	compareVersion:function(oldVersion, newVersion) {
		var newV = newVersion,
			old = oldVersion;
		if (parseInt(newV[0]) > parseInt(old[0])) {
				
			return true;
		}
		if (parseInt(newV[1]) > parseInt(old[1])) {
			
			return true;
		}
		
		if (parseInt(newV[2]) > parseInt(old[2])) {
			
			return true;
		}
		
		return false;
	},
	/**
	 * @description Parse first line of text file. Expect '//N.N.N\n'
	 * @return Array(3) of Integer
	*/
	getVersionFromFile:function(fileName) {
		var c = '', a = [], aB;
		if (PHP.file_exists(fileName)) {
			c = PHP.file_get_contents(fileName);
			aB = c.split('\n');
			c = aB[0];
		}
		c = c.replace('//', '');
		aB = c.split('.');
		a[0] = parseInt(aB[0]);
		a[1] = parseInt(aB[1]);
		a[2] = parseInt(aB[2]);
		
		a[0] = isNaN(a[0]) ? 0 : a[0];
		a[1] = isNaN(a[1]) ? 0 : a[1];
		a[2] = isNaN(a[2]) ? 0 : a[2];
		
		return a;
	}
};


function Autostart_OnFinishGetUnityPanelItems(out, err) {
	var i, qIsStart = false, ch, buf = '', arr = [], target = 'application://fastxampp.desktop', targetExists = 0;

	for (i = 0; i < out.length; i++) {
		ch = out.charAt(i);
		if (ch == "'") {
			qIsStart = !qIsStart;
			continue;
		}
		if (qIsStart) {
			buf += ch;
		} else if(buf.length){
			if (buf == target) {
				targetExists = true;
			}
			arr.push("'" + buf + "'");
			buf = '';
		}
	}
	
	if (!targetExists) {
		arr.push("'" + target + "'");
	}
	var command = '#! /bin/bash\n gsettings set com.canonical.Unity.Launcher favorites "[' + arr.join(', ') + ']"';
	
	PHP.file_put_contents(Qt.appDir() + '/data/unpack.sh', command);
	Exec.exec(Qt.appDir() + '/data/unpack.sh', 'F');
}

